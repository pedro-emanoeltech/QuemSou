﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuemSou.Models.Mapeamento
{
    public class Pessoas
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public int Idade { get; set; }
        public string Email { get; set; }
        public string Celular { get; set; }
        public string linkedin { get; set; }
        public string Foto { get; set; }
        public string Resumo { get; set; }

    }
}